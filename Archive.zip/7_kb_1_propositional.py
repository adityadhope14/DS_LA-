def modus_ponens(kb, f):
    nf = set(f)
    ch = True
    
    while ch:
        ch = False
        for r in kb:
            pre, con = r
            if all(p in nf for p in pre):
                if con not in nf:
                    nf.add(con)
                    ch = True
                    print(f"  inferred: {con} from {pre}")
    
    return nf

kb = [
    (["P", "Q"], "R"),
    (["R"], "S"),
    (["S", "T"], "U"),
    (["P"], "V"),
    (["V", "W"], "X"),
]

f = {"P", "Q", "T", "W"}

print("initial:", f)
print("\napplying:")

r = modus_ponens(kb, f)

print("\nfinal:", r)
print("derived:", r - f)
