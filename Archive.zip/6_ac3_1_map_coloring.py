from collections import deque

def revise(d, x, y):
    rev = False
    for c in d[x][:]:
        if not any(c != o for o in d[y]):
            d[x].remove(c)
            rev = True
    return rev

def ac3(g, d):
    q = deque((x, y) for x in g for y in g[x])
    
    while q:
        x, y = q.popleft()
        if revise(d, x, y):
            if not d[x]:
                return False
            for nb in g[x]:
                if nb != y:
                    q.append((nb, x))
    return True

def assign(g, d):
    r = {}
    for n in g:
        for c in d[n]:
            if all(r.get(nb) != c for nb in g[n]):
                r[n] = c
                break
    return r

g = {
    'A': ['B', 'C'],
    'B': ['A', 'C', 'D'],
    'C': ['A', 'B', 'D'],
    'D': ['B', 'C']
}

colors = ['Red', 'Green', 'Blue']
d = {n: colors[:] for n in g}

print("graph:", g)
print("initial:", d)

if ac3(g, d):
    print("\nafter ac3:", d)
    r = assign(g, d)
    print("\nassignment:")
    for n in sorted(r.keys()):
        print(f"  {n}: {r[n]}")
else:
    print("no solution")
