def safe(b, r, c):
    for i in range(r):
        if b[i] == c:
            return False
        if abs(b[i] - c) == abs(i - r):
            return False
    return True

def solve(b, r, n):
    global cnt
    if r == n:
        cnt += 1
        return
    
    for c in range(n):
        if safe(b, r, c):
            b[r] = c
            solve(b, r + 1, n)
            b[r] = -1

def solve_one(b, r, n):
    if r == n:
        return True
    
    for c in range(n):
        if safe(b, r, c):
            b[r] = c
            if solve_one(b, r + 1, n):
                return True
            b[r] = -1
    return False

def pboard(b, n):
    for r in range(n):
        for c in range(n):
            if b[r] == c:
                print("Q", end=" ")
            else:
                print(".", end=" ")
        print()

n = int(input("enter n: "))
b = [-1] * n

cnt = 0
solve(b, 0, n)
print(f"\ntotal solutions: {cnt}")

b = [-1] * n
if solve_one(b, 0, n):
    print(f"\none solution:")
    pboard(b, n)
