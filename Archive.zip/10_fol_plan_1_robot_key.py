from collections import deque

acts = {
    "pickup key": {
        "pre":    ["at robot rooma", "keyat rooma"],
        "add":    ["has key"],
        "remove": ["keyat rooma"],
    },
    "unlock door": {
        "pre":    ["at robot rooma", "has key", "locked door"],
        "add":    ["unlocked door"],
        "remove": ["locked door"],
    },
    "open door": {
        "pre":    ["at robot rooma", "unlocked door"],
        "add":    ["open door"],
        "remove": [],
    },
    "move ab": {
        "pre":    ["at robot rooma", "open door"],
        "add":    ["at robot roomb"],
        "remove": ["at robot rooma"],
    },
}

start = {"at robot rooma", "keyat rooma", "locked door"}
goal = {"at robot roomb"}

def find_plan(s, g):
    q = deque([(s, [])])
    vis = [s]
    
    while q:
        st, pl = q.popleft()
        
        if g.issubset(st):
            return pl
        
        for nm, ac in acts.items():
            if set(ac["pre"]).issubset(st):
                ns = (st - set(ac["remove"])) | set(ac["add"])
                if ns not in vis:
                    vis.append(ns)
                    q.append((ns, pl + [nm]))
    
    return None

pl = find_plan(start, goal)

if pl:
    print("plan found:")
    for i, s in enumerate(pl, 1):
        print(f"  step {i}: {s}")
else:
    print("no plan")
