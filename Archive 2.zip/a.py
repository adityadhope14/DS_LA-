g = {'A' : ['B','C'] , 'B' : ['A','C','D'] , 'C' : ['A' , 'B' , 'D'] , 'D' : ['B' , 'C']}
d = { x: ['R','G','B'] for x in g}
q = [(x,y) for x in g for y in g[x]]
while q : 
    x,y = q.pop(0)
    for c in d[x][:]:
        if all(c==v for v in d[y]):
            d[x].remove(c)
            if not d[x]:
                print("no solution")
                quit()
            q += [(z,x) for z in g[x] if z!=y]
print(d)            
