n = 4
board = [-1]*n
cnt = 0 
def solve(row):
    global cnt 
    if row ==n :
        cnt+=1
        print("Solutions:",board)
        return
    for col in range(n):
        safe = True
        for i in range(row):
            if(board[i]==col or abs(board[i]-col)==abs(i-row)):
                safe = False
                break
        if safe : 
            board[row] = col
            solve(row+1)
            board[row] = -1

solve(0)
print(cnt)


    