from sympy import Symbol, And

pr = [
    ("ram", "sita"),
    ("ram", "arjun"),
    ("sita", "priya"),
    ("mohan", "ram")
]

def parent(x, y):
    return (x, y) in pr

def child(x):
    return [c for p, c in pr if p == x]

def grandparent(x, y):
    return any(p == x and parent(c, y) for p, c in pr)

def sibling(x):
    return sorted({c for p, c in pr if c == x
                   for op, c2 in pr if op == p and c2 != x})

for p, c in pr:
    print(p, "parent of", c)

print("Ram parent of Sita:", parent("ram", "sita"))
print("Mohan grandparent of Sita:", grandparent("mohan", "sita"))
print("Ram grandparent of Priya:", grandparent("ram", "priya"))
print("Children of Ram:", child("ram"))
print("Siblings of Sita:", sibling("sita"))

P = Symbol("parent")
G = Symbol("grandparent")
print("Expression:", And(P, G))