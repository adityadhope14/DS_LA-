from collections import deque

start = {"robot_A", "key_A", "locked"}
goal = "robot_B"

q = deque([(start, [])])
visited = [start]

while q:
    s, p = q.popleft()

    if goal in s:
        print("Plan:", p)
        break

    actions = [
        ("pickup_key", {"robot_A", "key_A"}, {"has_key"}, {"key_A"}),
        ("unlock_door", {"robot_A", "has_key", "locked"}, {"unlocked"}, {"locked"}),
        ("open_door", {"robot_A", "unlocked"}, {"open"}, set()),
        ("move_B", {"robot_A", "open"}, {"robot_B"}, {"robot_A"})
    ]

    for name, pre, add, remove in actions:
        if pre <= s:
            new = (s - remove) | add

            if new not in visited:
                visited.append(new)
                q.append((new, p + [name]))
else:
    print("No plan")