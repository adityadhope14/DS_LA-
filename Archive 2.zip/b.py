kb = [
    (["p" , "q"] , "r"),
    (["r" ] , "s"),
    (["s" , "t"] , "u"),
    (["v" , "w"] , "x")
]
facts = {"P","Q","T","W"}
print("Initial:" , facts)
while True:
    changed = False
    for conditions , result in kb:
        if all(x in facts for x in conditions) and result not in facts:
            facts.add(result)
            print("Inferred :" , result)
            changed = True
    if not changed:
        break
print('FInal:' , facts)
print("new" , facts - {'P',"Q" , "T" , "W"})            